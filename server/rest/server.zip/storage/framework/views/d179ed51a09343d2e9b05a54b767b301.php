<tr>
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($user->email); ?></td>
    <td><?php echo e($user->user_uuid); ?></td>
    <td><?php echo e($user->role); ?></td>

    <td>
        <form action="<?php echo e(route('user.promote', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <button type="submit" class="btn btn-link">
                <i class="fas fa-arrow-up"></i>
            </button>
        </form>
    </td>
    <td>
        <form action="<?php echo e(route('user.demote', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <button type="submit" class="btn btn-link">
                <i class="fas fa-arrow-down"></i>
            </button>
        </form>
    </td>
    <td>
        <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-link">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    </td>
</tr>


<?php /**PATH /home/ishaan/Documents/dev/Projects/KaizenKlass/dev/KaizenKlass-V2/server/rest/resources/views/includes/user/table-record.blade.php ENDPATH**/ ?>