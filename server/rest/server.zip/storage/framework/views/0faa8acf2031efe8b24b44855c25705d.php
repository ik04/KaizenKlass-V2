<?php $__env->startSection('content'); ?>
    <h4 class="text-black">Add User</h4>
    <?php echo $__env->make('includes/success-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes/user/register-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ishaan/Documents/dev/Projects/KaizenKlass/dev/KaizenKlass-V2/server/rest/resources/views/pages/user/add.blade.php ENDPATH**/ ?>