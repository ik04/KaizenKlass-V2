<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes/success-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Add Subject Form</h5>

            <!-- Horizontal Form -->
            <form action="<?php echo e(route('subject.create')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Subject</label>
                    <div class="col-sm-10">
                        <input type="text" name="subject" class="form-control" id="inputText">
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form><!-- End Horizontal Form -->

        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Add Subjects Form</h5>
            <!-- Horizontal Form -->
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('subject.create.multiple')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Subjects</label>
                    <div class="col-sm-10">
                        <textarea name="subjects" class="form-control" style="height: 100px"></textarea>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form><!-- End Horizontal Form -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ishaan/Documents/dev/Projects/KaizenKlass/dev/KaizenKlass-V2/server/rest/resources/views/pages/subjects/add.blade.php ENDPATH**/ ?>