<tr>
    <td><?php echo e($subject->id); ?></td>
    <td><?php echo e($subject->subject); ?></td>
    <td><?php echo e($subject->subject_uuid); ?></td>
    <td><?php echo e($subject->created_at); ?></td>
    <td>
        <form action="<?php echo e(route('subject.destroy', $subject->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-link">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    </td>
</tr>
<?php /**PATH /home/ishaan/Documents/dev/Projects/KaizenKlass/dev/KaizenKlass-V2/server/rest/resources/views/includes/subjects/table-record.blade.php ENDPATH**/ ?>