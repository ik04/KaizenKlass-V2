<?php

namespace App\Exceptions;

use Exception;

class IncorrectPasswordException extends Exception
{
    //
}
