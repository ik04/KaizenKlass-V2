<?php

namespace App\Exceptions;

use Exception;

class SolutionNotFoundException extends Exception
{
    //
}
