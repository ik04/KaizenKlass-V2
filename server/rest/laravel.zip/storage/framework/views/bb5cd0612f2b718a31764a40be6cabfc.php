<section class="section">
    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Subjects</h5>
                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th>
                                    <b>i</b>d
                                </th>
                                <th>Subject</th>
                                <th>Uuid</th>
                                <th data-type="date" data-format="YYYY/DD/MM">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($subject->id); ?></td>
                                <td><?php echo e($subject->subject); ?></td>
                                <td><?php echo e($subject->subject_uuid); ?></td>
                                <td><?php echo e($subject->created_at); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php /**PATH /home/ishaan/Documents/dev/Projects/KaizenKlass/dev/KaizenKlass-V2/server/rest/resources/views/includes/subjects/table.blade.php ENDPATH**/ ?>