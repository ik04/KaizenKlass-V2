<?php

namespace App\Enums;

enum Resource: int
{
    case RESOURCE = 0;
    case TRACKER = 1;
}