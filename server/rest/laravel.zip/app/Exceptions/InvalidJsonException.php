<?php

namespace App\Exceptions;

use Exception;

class InvalidJsonException extends Exception
{
    //
}
