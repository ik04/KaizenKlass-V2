<?php

namespace App\Exceptions;

use Exception;

class SubjectNotFoundException extends Exception
{
    //
}
